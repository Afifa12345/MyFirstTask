import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
 // MyHomePage({Key key}) : super(key: key);
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('My first task'),
      ),
      body: Column(
        children: <Widget>[
          Container(
            height: MediaQuery.of(context).size.height / 3.7, // get information of what size device you are on
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: NetworkImage( //image ko import karny ka new tarqqea ha wysy to assets ky saaty bi kar sakty hain per yah asan ha
                    'https://image.shutterstock.com/image-photo/mountain-landscape-lake-range-large-260nw-1017466240.jpg'),
              ),
            ),
          ),
          SizedBox(
            height: 40,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: <Widget>[
                Column(
                  children: <Widget>[
                    Text(' lakes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20,
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Text('lakes, Pakistan', style: TextStyle(fontSize: 18, color: Colors.brown, fontWeight: FontWeight.w100,
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    Icon(Icons.star, color: Colors.red,
                    ),
                    Text("41", style: TextStyle(fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(
            height: 50,
          ),
          Padding(padding: const EdgeInsets.only(left: 16, right: 16), child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                GestureDetector(onTap: () {
                    showDialog(context: context, builder: (BuildContext context) {
                          return SimpleDialog(
                            title: Text('Dialog box'),
                            children: [
                              SimpleDialogOption(onPressed: () => Navigator.pop(context, ''),
                                child: Text('Call button'),
                              ),
                            ],
                          );
                        });
                  },
                  child: Column(children: <Widget>[
                      Icon(Icons.call, color: Colors.blue,
                      ),
                      Text('\nCALL', style: TextStyle(color: Colors.blue,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(onTap: () {
                    showDialog(context: context, builder: (BuildContext context) {
                        return AlertDialog(
                          title: Text('Alert Dialog'),
                          content: Text('Route button'),
                          actions: [
                            TextButton(onPressed: () => Navigator.pop(context, 'OK'), child: Text('OK'),
                            ),
                          ],
                        );
                      },
                    );
                  },
                  child: Column(children: <Widget>[
                      Icon(Icons.near_me, color: Colors.blue,
                      ),
                      Text('\nROUTE', style: TextStyle(color: Colors.blue,
                        ),
                      ),
                    ],
                  ),
                ),
                GestureDetector(onTap: () {
                    showModalBottomSheet(context: context, builder: (BuildContext context) {
                          return Container(height: 200,
                            child: Padding(padding: const EdgeInsets.all(16.0),
                              child: Column(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                children: <Widget>[
                                  Text(
                                    'Bottom Sheet',
                                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        });
                  },
                  child: Column(
                    children: <Widget>[
                      Icon(Icons.share, color: Colors.blue,
                      ),
                      Text('\nSHARE',
                        style: TextStyle(color: Colors.blue,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(
            height: 50,
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15, right: 15),
            child: Row(mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(width: MediaQuery.of(context).size.width - 50,
                  child: Text(
                     'Pakistan is home to many natural and man made lakes and reservoirs. The largest lake in Pakistan is the Manchar Lake, which is also the largest lake in South Asia. The lake is spread over an area of over 260 square kilometres (100 square miles)',
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
